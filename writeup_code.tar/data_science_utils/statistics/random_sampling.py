def rejection_sample_batch():
    pass
