"""
Takes in a list of measurements, drugs, etc.
Generates a query which may be read into a Pandas DataFrame.
"""
