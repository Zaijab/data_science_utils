class A:
    @property
    def dimension(self):
        return 1


my_object = A()
# my_object.dimension = 2 # error!
