from sklearn.linear_model import LogisticRegression

classifiers = {"Logistic Regression": LogisticRegression()}
