import jax
import equinox as eqx
from jaxtyping import Float, Array

