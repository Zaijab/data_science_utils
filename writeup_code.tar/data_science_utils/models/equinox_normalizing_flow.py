import jax
import jax.numpy as jnp
import optax
from tqdm import tqdm
import matplotlib.pyplot as plt

import equinox as eqx

class DenseNetwork(eqx.Module):
    pass

class CouplingLayer(eqx.Module):
    pass

class PLULayer(eqx.Module):
    pass

class QRLayer(eqx.Module):
    pass

class InvertibleNN(eqx.Module):
    pass

test_x = DenseNetwork()
